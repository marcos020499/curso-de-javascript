import './App.css';
import Fetch from './Components/Fetch'
import Button from './Components/Button'
import Text from './Components/Texto'

import React from 'react';

function App(props) {
  return (
    <>
      <Fetch/>
  </>
  );

}


export default App;
